from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
import tensorflow as tf
import cv2

model_path = 'detector/static/modelv1.h5'
print("Model Path:", model_path)
# Load the model
model = tf.keras.models.load_model(model_path)
# Create your views here.
@csrf_exempt
def home(request):
    if request.method =="POST":
        image =request.FILES.getlist('Upload Image')
        detected_image=predict_detection_for_single_image(image)
    return render(request, 'index.html' )

# Function to perform detections with trained model
def predict_detection_for_single_image(image_path):
    # Read the image
    image = cv2.imread(image_path)
    
    # Pass the image through the detection model and get the result
    detect_result = model(image)
    
    # Plot the detections
    detect_image = detect_result[0].plot()
    
    # Convert the image to RGB format
    detect_image = cv2.cvtColor(detect_image, cv2.COLOR_BGR2RGB)
    
    return detect_image

